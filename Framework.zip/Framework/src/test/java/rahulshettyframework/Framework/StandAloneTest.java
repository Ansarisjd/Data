package rahulshettyframework.Framework;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.fasterxml.jackson.core.sym.Name;

import rahulshettyacademy.pageobjects.LandingPage;

public class StandAloneTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Divyesh Pawaskar\\Documents\\Sajid Ansari\\ChromeDriver\\chromedriver_win32//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		String productName = "ADIDAS ORIGINAL";
		ChromeDriver driver = new ChromeDriver(options);
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://rahulshettyacademy.com/client");
		driver.manage().window().maximize();
		
			
		LandingPage landingpage = new LandingPage(driver);
        landingpage.loginApplication("ansarisjdmohd3072@gmail.com", "Password0");
        
        //WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5)); 
		
		
		
		
		driver.findElement(By.xpath("//*[@id=\"userEmail\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"userEmail\"]")).sendKeys("ansarisjdmohd3072@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"userPassword\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"userPassword\"]")).sendKeys("Password0");		driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
	   
		// 1) we are trying to add the product to the card through For Loop but it is not working 
		List<WebElement> products= driver.findElements(By.xpath("//b[contains(text(), 'zara coat 3') or contains(text(), 'adidas original') or contains(text(), 'iphone 13 pro')]"));
		for(int i=0; i<products.size();i++)
		{  String name = products.get(i).getText();
		 if(name.contains("ADIDAS ORIGINAL"))
		 {
			 driver.findElements(By.xpath("//button[contains(@class, 'btn') and contains(@class, 'w-10') and contains(@class, 'rounded') and contains(@style, 'float: right;') and .//i[contains(@class, 'fa fa-shopping-cart')]]")).get(i).click();
		     break;
		 }
		 
		}
	    
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector("#toast-container")));
		wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.cssSelector(".ng-animating"))));
		driver.findElement(By.cssSelector("[routerlink*='cart']")).click();
		
		List <WebElement> cartproducts = driver.findElements(By.cssSelector(".cartSection h3"));
		Boolean match = cartproducts.stream().anyMatch(cartproduct-> cartproduct.getText().equalsIgnoreCase(productName));
		Assert.assertTrue(match);
		driver.findElement(By.cssSelector(".totalRow button")).click();
//		driver.close();
		Actions a = new Actions(driver);
		a.sendKeys(driver.findElement(By.cssSelector("[placeholder=\"Select Country\"]")), "india").build().perform();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".ta-results")));
		driver.findElement(By.xpath("//button[contains(@class,'ta-item')][2]")).click();
		driver.findElement(By.cssSelector(".btnn.action__submit.ng-star-inserted")).click();
		String confirmation = driver.findElement(By.cssSelector(".hero-primary")).getText();
		Assert.assertTrue(confirmation.equalsIgnoreCase("THANKYOU FOR THE ORDER."));
		driver.close();                    
		
		
		
        // 2) in this code we are trying to Add Products to the cart through Streams as guided in the Lecture.
		
//		List<WebElement> items = driver.findElements(By.cssSelector(".mb-3"));
//    	WebElement prod = items.stream().filter( item -> item.findElement(By.cssSelector("b")).getText().equals("ZARA COAT 3")).findFirst().orElse(null);
//    	prod.findElement(By.cssSelector(".card-body botton:last-of-type")).click();
		
       
	    
	    
	}

}
