package rahulshettyacademy.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import rahulshettyacademy.AbstractComponents.AbstractComponent;

public class ProductCatalogue extends AbstractComponent{
	
	WebDriver driver;
	
	public ProductCatalogue(WebDriver driver){
	 // Initializer
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	//List<WebElement> products= driver.findElements(By.xpath("//b[contains(text(), 'zara coat 3') or contains(text(), 'adidas original') or contains(text(), 'iphone 13 pro')]"));
	
	@FindBy(xpath="//b[contains(text(), 'zara coat 3') or contains(text(), 'adidas original') or contains(text(), 'iphone 13 pro')]")
	List <WebElement> products;
	
	
	public getProductList()
	{
		waitForElementToAppear(null);
	}
	
 }
	  
	  
	  
	  
  
  
  
  
  

