package rahulshettyacademy.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import rahulshettyacademy.AbstractComponents.AbstractComponent;

public class LandingPage extends AbstractComponent{
	
	WebDriver driver;
	
	public LandingPage(WebDriver driver){
	 // Initializer
		super(driver);
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	
	
	//WebElement userEmail = driver.findElement(By.xpath("//*[@id=\"userEmail\"]"));
	// Page Factory for reducing Syntax
 
  @FindBy(xpath="//*[@id=\"userEmail\"]")
  WebElement userEmail ;
   // for giving knowledge of driver we need to import pagefactory class and need to pass PageFactory.initElements(driver, this); in constructor itself

    //	driver.findElement(By.xpath("//*[@id=\"userPassword\"]")).click();
  @FindBy(xpath="//*[@id=\"userPassword\"]")
  WebElement password ;	
  	
  	//driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
  @FindBy(xpath="//*[@id=\\\"login\\\"]")  
  WebElement submit ;
  
  public void loginApplication(String email,String Password) {
	  userEmail.sendKeys(email);
	  password.sendKeys(Password);
	  submit.click();
  }  
 
  public void goTo() {
	  driver.get("https://rahulshettyacademy.com/client");
 
 }
	  
	  
	  
	  
  }
  
  
  
  

