package Demo;

public class Basic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 1) Validate if add place API is working as expected
	       
			// Rest Assured works on three conditions 
			//Given -- All Input Details
			//When  -- Submit The API
			//Then  --
		
		RestAssured.
		
	}

}
