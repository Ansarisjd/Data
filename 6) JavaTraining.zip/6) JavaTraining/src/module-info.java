/**
 * 
 */
/**
 * 
 */
module JavaTraining {
}