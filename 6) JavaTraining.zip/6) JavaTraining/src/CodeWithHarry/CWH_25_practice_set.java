package CodeWithHarry;

import java.util.Scanner;

public class CWH_25_practice_set {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//  1) write a program to print * in below pattern
		// ****
		// ***
		// **
		// *
	// Code 1	
//		int n = 4;
//		for (int i = n; i>0; i--) {
//			for(int j=0; j<i; j++) {
//				System.out.print("*");
//			}
//		System.out.print("\n");
//		}
		
	// Code 2	
//		        int rows = 4;
//
//		        for (int i = 0; i < rows; i++) {
//		            for (int j = 0; j < rows - i; j++) {
//		                System.out.print("*");
//		            }
//		            System.out.println();
//		        }
		    
// 2) Write a program to sum first 3 even numbers using while loop.		
		
//     int sum = 0;
//     int n = 3;
//     for(int i = 0; i<n ; i++) {
//    	 sum = sum +(2*i);
//     }
//	System.out.print("Sum of even numbers is : ");
//	System.out.println(sum);
	
// 3) Write a program to print multiplication table of a given number n.
	

//	for(int i=0;i<=10;i++) {
//		System.out.println(i*2);
//	}
		
// 4) Write a program to print multiplication of table 10 in reverse order
	
//		for(int i=10;i>0;i--) {
//			System.out.println(i*10);
//	}
	
//	5) Write a program to find factorial of a given number using for loop
		
		
//			 Scanner scanner = new Scanner(System.in);
//
//		        // Get the number from the user
//		        System.out.print("Enter the number for multiplication table: ");
//		        int n = scanner.nextInt();
//
//		        // Print the multiplication table
//		        System.out.println("Multiplication table for " + n + ":");
//		        for (int i = 1; i <= 10; i++) {
//		            System.out.println(n + " * " + i + " = " + (n * i));
//		        }
//
//		        // Close the scanner
//		        scanner.close();
		

//  6) Repeat 5 using while loop
		
//		int n = 5;
//		int i = 1;
//		int factorial = 1;													
//		while(i<=n) {
//			factorial *=i;
//			i++;
//		}
//		System.out.println(factorial);

	
// 9) Write a program to calculate the sum of the numbers occuring in the multiplication table of 8.	
	
		int n = 8;
		int sum = 0;
		for(int i=1; i<=10;i++) {
			sum += n*i;
		}
	    System.out.println(sum);
	}
		
	}		

	


