package CodeWithHarry;

public class LoopsPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
	// 1)  While Loops :- It will execute until the condition become false. If condition never become false it will be executing continuously.
		System.out.println(1);
		System.out.println(2);
		System.out.println(3);
		int i = 1;
		while(i<=3) {
			System.out.println(i);
			i++;
	
	// 2) Do While Loops :- In do while loop first it will execute the function then it will check the condition If 
			
//		int b = 10;
//		do {
//			System.out.println(b);
//			b++;
//		} while (b<5);
		
	// 3) For loop it is the simplest & smallest loop amongst all
		
//		int c = 9;
//		for(c=0; c<=9;c++ ) {
//			System.out.println(c);
//		}
		
		
		
		
		
		
		
		}
	
	}

}
