package CodeWithHarry;

public class ifElse_ElseIf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
	// 1) Example Of If Else Clause
		
	int NoOfDeath = 64;
    if( NoOfDeath < 64) {
    	System.out.println("False");
    	
    }
    else {
    	System.out.println("True");
    }
	
    
    // 2) Example Of Else If Caluse
    
    int age = 18;
    if(age < 18) {
    	System.out.println("You are a child");
    }
    else if (age == 18) {
    	System.out.println("Now You Are Adult");
    }
    
    else if (age>18) {
    	System.out.println("Now you are eligible for marriage");
    }
    
 
   
    
	}

}
