package CodeWithHarry;

import java.util.Scanner;

public class PracticeSet1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  // 1) Question 1:- write down a program calculating CGPA of 3 subjects
		
//	int maths = 49;
//    int english = 85;
//    int geo = 70 ;
//    int average = (maths+english+geo)/3;
//    float cgpa = average/10f;
//    System.out.println(average);
//    System.out.println(cgpa);

   // 2) write a program which ask user to enter his name & greet the with "Hello 'Name' have a good day"
//    System.out.println("What is your name");
    Scanner sc = new Scanner(System.in);
//    String name = sc.next();
//    System.out.println("Hello "  + name  + " have a good day!");
    
   // 3) Write a java program to convert kilometer to miles
    
//    System.out.println("Write down the km to convert it into miles");
//    double km = sc.nextDouble();
//    double miles = km*0.621371;
//    System.out.println("Miles is " + miles);
    
   // 4) write down a java program to detect whether a number enter by user is integer or not.
    
//    System.out.print("Enter a number: ");

//    if (sc.hasNextInt()) {
//        int number = sc.nextInt();
//        System.out.println("The entered number is an integer: " + number);
//    } else {
//        String input = sc.next();
//        System.out.println("The entered value is not an integer: " + input);
//    }
   // 5) Write a program to find out whether a student is pass or fail if it requires total 40% & atleast 33% in each subject from taking input from user.
//   byte m1 , m2 , m3 ;
//    
//    System.out.println("Enter yoyr marks in physics");
//    m1= sc.nextByte();
//    
//    System.out.println("Enter yoyr marks in chemistry");
//    m2= sc.nextByte();
//    
//    System.out.println("Enter yoyr marks in maths");
//    m3=sc.nextByte();
//    
//    float avg = (m1+m2+m3)/3.0f;
//    
//    if(avg>=40 && m1 >=33 && m2 >=33 && m3 >=33) 
//    {
//    System.out.println("Contratulations ! You have been promoted ");    
//   
//	}
//    else {
//    	System.out.println("Sorry ! You have not been promoted ");
//    }
	
    // 6) calculate income tax paid by an employee the the government as per the slab mentioned below 
    
    // Income         SLAB
    // 2.5L - 5L      5%
    // 5L   - 10L    20%
    // 10L  - Above  30%
    
  
    
	}
}
