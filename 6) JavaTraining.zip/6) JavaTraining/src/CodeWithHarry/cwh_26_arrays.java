package CodeWithHarry;

public class cwh_26_arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
		// There are three ways of creation of array
		
		// 1) 
		
		//int [] marks;              Declaration
		//marks = new int[5];        Memory Allocation
		 
		// marks[0] = 100;
		// marks[1] = 60;
		// marks[2] = 100;
		// marks[3] = 100;
		// marks[4] = 100;
		
		
		// 2) Declaration & Memory allocation!
		//int [] marks = new int[5];
	
      	// 3) int [] marks = {100,72,80,71,98}     Declare + Initialize!
	}

}
