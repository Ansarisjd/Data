package CodeWithHarry;

public class CWH_27_LoopsWithArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int [] marks = {90,42,80,98,100,43};
    for(int i=0; i<marks.length; i++) {
    	System.out.println(marks[i]);
    }
    
    System.out.println("Now Running Loop in reverse order.");
    
    for(int i=marks.length -1; i>=0; i--)
    {
    	System.out.println(marks[i]);
    }
    
    System.out.println("Now Printing Through For Each Loop");
    
    for(int Element:marks) {
    	System.out.println(Element);
    }
    
    
	}

}
