package CodeWithHarry;

public class CWH_31_Methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
