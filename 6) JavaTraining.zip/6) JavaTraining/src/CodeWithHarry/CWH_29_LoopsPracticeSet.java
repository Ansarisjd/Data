package CodeWithHarry;

public class CWH_29_LoopsPracticeSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    // 1) Create array of 5 float and calculate their sum.
//		float sum = 0;
//		float [] numbers = {36.2f,58.98f,54.9f,20.1f,34.5f};
//		for(float element:numbers){
//			sum = sum + element;
//			
//		}
//		System.out.println("The Sum Of All Float Is" + sum);
		
	// 2) Write a Program to find out whether a given integer is present in an array or not.
		
//		int [] marks = {42,38,50,54,98};
//		for(int i = 0;i<marks.length;i++)
//			if(i==43) {
//				System.out.println("43 marks is present");
//				
//			}else {break;}
//		System.out.println("Not Found");
		
		
//		3) Calculate the Average marks from an Array containing marks of all students in physics using for each loop.
//		     int sum=0;
//		int [] marks = {42,30,50,48,30,98};
//		for(int element:marks) {
//			sum = sum+element;
//			}
//		System.out.println("Average Marks Of Physics Of Student is " +  sum/marks.length);
	
//     4) Create a Java program to add two matrices of Size 2X3	.
		
//	int[][] mat1 = { { 1, 2, 3 },
//			         { 4, 5, 6 } };
//
//	int[][] mat2 = { { 2, 6, 13 },
//			         { 3, 7, 11 } };
//
//	int[][] result = { { 0, 0, 0 },
//			           { 0, 0, 0 } };
//
//	for (int i = 0; i < mat1.length; i++) {// row number of times
//		
//		for (int j = 0; j < mat1[i].length; j++) {// Column Number of times
//			System.out.format("Setting value for i=%d and j=%d\n", i, j);
//			result[i][j] = mat1[i][j] + mat2[i][j];
//		}
//	}
//
//	for (int i = 0; i < mat1.length; i++) {
//		for (int j = 0; j < mat1[i].length; j++) {
//			System.out.print(result[i][j] + " ");
//			result[i][j] = mat1[i][j] + mat2[i][j];
//
//		}
//		System.out.println("");
//	}


		
//     5) Write a java program to reverse an array.		
		
//		int [] arr = {1, 2, 3, 4, 5, 6};
//		int l = arr.length;
//		int n = Math.floorDiv(l, 2);
//		int temp;
//		
//		for(int i=0; i<n; i++) {
//			// Swap a[i] and a{l-1-1};
//			 // a b Temp;
//			// |4||3| ||;
//			
//			temp = arr[i];
//			arr[i] = arr[l-i-1];
//			arr[l-i-1] = temp;
//		}
//        for(int element : arr) {
//        	System.out.print(element + " ");
//        }

//     6) Write a java program to find the maximum element in an array
        
//        int [] arr = {1, 123,45,879,896,900};
//        int max = 0;
//        for(int e : arr){
//        	if(e>max) {
//        		max = e;
//        	}
//        }
//		System.out.println("the value of the maximum element in this array is:" + max);
		
//     7) Write a java program to find the minimum element in an array
		
  
//		int[] arr = {300, 123, 45, 879, 896, 900};
//
//        // Initialize min with the first element of the array
//        int min = arr[0];
//        // Loop through the array to find the minimum element
//        for (int i = 0; i < arr.length; i++) {
//            if (arr[i] < min) {
//                min = arr[i];
//            }
//        }
//
//        System.out.println("Minimum element in the array: " + min);
       
	
	
//     8) Write a program to find whether an array is sorted or not.
		
//		boolean isSorted = true;
//		int [] arr = {144, 1000, 3 ,54,5000};
//		for(int i=0; i<arr.length; i++) {
//			if(arr[i]> arr[i+1]) {
//				isSorted = false;
//				break;
//			}
//		}
//		if(isSorted) {
//			System.out.println("The Array Is Sorted");
//		}
//		else {System.out.println("The Array Is Not Sorted");}
	}

}
