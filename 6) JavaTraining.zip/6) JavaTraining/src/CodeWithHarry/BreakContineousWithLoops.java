package CodeWithHarry;

public class BreakContineousWithLoops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
		// 1)  Example Of Break
//		for (int i = 0; i < 50; i++) {
//			System.out.println(i);
//			System.out.println("Java is great");
//
//			if (i == 2) {
//				System.out.println("Ending The Loop");
//				break;
//			}
//	}
        // 2) Example of Continue 
		
		for (int i = 0; i < 50; i++) {
			if (i == 2) {
				System.out.println("Java is great");
				continue;
			}

			System.out.println(i);
			System.out.println("Ending The Loop");
			
	}
		
		
}
}