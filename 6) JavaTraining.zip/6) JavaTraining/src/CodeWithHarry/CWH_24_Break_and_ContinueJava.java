package CodeWithHarry;

public class CWH_24_Break_and_ContinueJava {

	public static void main(String[] args) {
		// Break and Continue Using Loops!
		for(int i=0;i<50;i++) {
			
			if(i==3) {
				System.out.println("Ending the loop");
				continue;
			}
			System.out.println(i);
			System.out.println("Java is great");
			
//		int i = 0;
//		while(i<=50) {
//			System.out.println(i);
//			i++;
//			if(i==3) {
//				System.out.println("Exit the loop");
//				break;
				
//				int i = 0;
//				while(i<=50) {
//					System.out.println(i);
//					i++;
//					if(i==3) {
//						System.out.println("Exit the loop");
//						continue;		
	}
		
			
				
		}

	}


