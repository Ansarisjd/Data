package CodeWithHarry;

public class CWH_28_MultiDiamentionalArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int [][] flat; // 2D array
    flat = new int [2][3];
    flat[0][0] = 101;
    flat[0][1] = 102;
    flat[0][2] = 103;
    flat[1][0] = 201;
    flat[1][1] = 202;
    flat[1][2] = 203;
    
    for(int i = 0; i<flat.length; i++) {
    	for(int j=0;j<flat[i].length; j++) {
    		System.out.println(flat[i][j]);	
    	}
    	
    }
    
    
	}

}
