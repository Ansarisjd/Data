package CodeWithHarry;



    class Employee{
    	int salary;
    	String name;
    	
    	public int getSalary(){
			return salary;	
    	}
    public String getName() {
    	return name;
    }
    
   public void setName(String n) {
	   name = n;
   }
    
    }
    public class CWH_39_Chapter8PrecticeSet {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    // Problem 1
	Employee harry = new Employee();
	harry.setName("CodeWithHarry");
	harry.getName();
		
	
	}

}
