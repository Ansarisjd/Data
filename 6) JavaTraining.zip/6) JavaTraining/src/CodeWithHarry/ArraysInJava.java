package CodeWithHarry;

public class ArraysInJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
	// There are 3 ways to create arrays in java
	
	
	//1) 	
//int [] marks ;           // Declaration
//marks = new int [5];     // Memory Allocation
//     marks[0] = 100;
//     marks[1] = 150;
//     marks[3] = 120;
//     marks[4] = 100;
//     marks[5] = 130;
    
    //2) 
//int[] marks = new int[5];  // Declaration + Memory Allocation
		// Creation Of Arrays will be the same as above
		
	//3) Declaration , Memory Allocation & Initialization In this way we are not allocating memory to the array it will be done by java automatically.
		int [] marks = {98, 45, 79, 99, 80};
		
		
		
		
	}

}
