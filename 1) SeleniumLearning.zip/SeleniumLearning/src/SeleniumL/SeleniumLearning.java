package SeleniumL;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumLearning {

	public static void main(String[]args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Divyesh Pawaskar\\Downloads\\chromedriver_win32 (4).exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com");
		System.out.println(driver.getTitle());
		
		
		
		
		
		
		
		
		
		
	
		
		
		
		
		
		
		
	}

}
