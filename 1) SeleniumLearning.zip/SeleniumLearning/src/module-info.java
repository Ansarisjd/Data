
module SeleniumLearning {
	requires org.seleniumhq.selenium.chrome_driver;
	requires org.seleniumhq.selenium.api;
	requires io.github.bonigarcia.webdrivermanager;
}