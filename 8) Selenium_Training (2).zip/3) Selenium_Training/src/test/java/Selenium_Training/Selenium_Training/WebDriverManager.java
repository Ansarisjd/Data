package Selenium_Training.Selenium_Training;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class WebDriverManager {

	public static void main(String[] args) {
		// Create a ChromeDriver instance
//		ChromeOptions options = new ChromeOptions();
//		WebDriverManager.chromedriver().setup();
//        WebDriver driver = new ChromeDriver();
        
        ChromeOptions chromeOptions = new ChromeOptions();
        //WebDriverManager.chromeriver().setup();
		WebDriver driver = new ChromeDriver(chromeOptions);
		
		// Navigate to the demoqa website
		driver.get("https://www.demoqa.com");
		
		driver.quit();

	}

	
	}


