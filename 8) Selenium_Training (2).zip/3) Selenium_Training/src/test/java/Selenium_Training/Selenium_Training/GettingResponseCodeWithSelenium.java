package Selenium_Training.Selenium_Training;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import com.google.common.collect.Streams;

public class GettingResponseCodeWithSelenium {

	public static void main(String[] args) throws MalformedURLException, IOException, InterruptedException {
		//Knowing weather links are working or not
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Divyesh Pawaskar\\Documents\\Sajid Ansari\\ChromeDriver\\chromedriver-win64//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		
		//......working link
//		String url = driver.findElement(By.cssSelector("a[href*='soapui']")).getAttribute("href");
//		
//		HttpURLConnection conn = (HttpURLConnection)new URL(url).openConnection();
//		conn.setRequestMethod("HEAD");
//		conn.connect();
//		System.out.println(conn.getResponseCode());
        
		
		
		//......BrokenLink
        Thread.sleep(5000);
		String broken = driver.findElement(By.cssSelector("a[href*='brokenlink'])")).getAttribute("href");
        HttpURLConnection d = (HttpURLConnection) new URL(broken).openConnection();
        d.setRequestMethod("HEAD");
        d.connect();
        System.out.println(d.getResponseCode());
        
        //....iterating on all links available
//        List<WebElement> links = driver.findElements(By.cssSelector("li[class*='gf']"));
//        // we will use enhanced for loop
//        for(WebElement link : links)
//        {String broken = link.getAttribute("href");
//        HttpURLConnection d = (HttpURLConnection) new URL(broken).openConnection();
//        d.setRequestMethod("HEAD");
//        d.connect();
//        int response = d.getResponseCode();
//        System.out.println(response);
//        if(response>400)
//        {
//        	System.out.println("The link with text" + link.getText() + "is broken with code"+response);
//        	Assert.assertTrue(false);
//        }
        
        driver.close();
        
        
        
	}
   
       
}

