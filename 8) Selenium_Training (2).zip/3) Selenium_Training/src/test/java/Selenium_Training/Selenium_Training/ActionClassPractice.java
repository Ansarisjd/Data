package Selenium_Training.Selenium_Training;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class ActionClassPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",
				"C:\\\\Users\\\\Divyesh Pawaskar\\\\Documents\\\\Sajid Ansari\\\\ChromeDriver\\\\chromedriver-win64 in use\\\\chromedriver-win64 V_120//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);
       // Handing Keyboard with selenium using Actions Class
		driver.get("https://www.amazon.com/");
		Actions a = new Actions(driver);
	    a.moveToElement(driver.findElement(By.xpath("//*[@id=\"nav-search-bar-form\"]"))).click().keyDown(Keys.SHIFT).sendKeys("hello").build().perform();
		
		
		
		
	}

}
