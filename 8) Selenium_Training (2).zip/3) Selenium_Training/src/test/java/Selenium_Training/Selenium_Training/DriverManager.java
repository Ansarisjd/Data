package Selenium_Training.Selenium_Training;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class DriverManager {

	
		public static void main(String[] args) throws InterruptedException {
			// Set the driver path
			System.setProperty("webdriver.edge.driver", "C:\\Users\\Divyesh Pawaskar\\Downloads\\edgedriver_win64 (1)//msedgedriver.exe");

			// Start Edge Session
			WebDriver driver = new EdgeDriver();

			driver.get("https://google.com");

			driver.quit();

}
}