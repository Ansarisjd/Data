package Selenium_Training.Selenium_Training;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
public class Driver {

	public static void main(String[] args) throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Divyesh Pawaskar\\Documents\\Sajid Ansari\\ChromeDriver\\chromedriver-win64//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		//below arguments is for opening same browser login every time.
		//options.addArguments("--profile-directory=Profile 2");
		//options.addArguments("--user-data-dir=C:\\Users\\Divyesh Pawaskar\\AppData\\Local\\Google\\Chrome\\User Data\\");
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://www.freecrm.com/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/div[2]/div/div[2]/ul/a")).click();
		driver.findElement(By.xpath("//*[@id=\"ui\"]/div/div/form/div/div[1]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"ui\"]/div/div/form/div/div[1]/div/input")).sendKeys("ansarisjdmohd3072@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"ui\"]/div/div/form/div/div[2]/div/input")).click();
		driver.findElement(By.xpath("//*[@id=\"ui\"]/div/div/form/div/div[2]/div/input")).sendKeys("Sajid1620");
		driver.findElement(By.xpath("//div[contains(@class,'fluid')]")).click();
		Thread.sleep(5000);
		System.out.println(driver.findElement(By.xpath("//*[@id=\"top-header-menu\"]/div[2]/span[2]/a/span")).getText());
		Thread.sleep(5000);
		assertEquals("4 days Pro trial", driver.findElement(By.xpath("//*[@id=\"top-header-menu\"]/div[2]/span[2]/a/span")).getText());
    	WebElement StaticDropdown = driver.findElement(By.id("dropdown-class-example"));
		Select dropdown = new Select(StaticDropdown);
     	dropdown.deselectByIndex(3);
		driver.close();
		
		
		
		
		
		
	}

	private static boolean assertArrayEquals(WebElement findElement, String string) {
		// TODO Auto-generated method stub
		return false;
	}

}
