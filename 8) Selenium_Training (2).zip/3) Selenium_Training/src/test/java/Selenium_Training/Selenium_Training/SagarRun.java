package Selenium_Training.Selenium_Training;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.managers.ChromeDriverManager;

public class SagarRun {

	
		public static void main(String[] args) throws InterruptedException {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Divyesh Pawaskar\\Documents\\Sajid Ansari\\ChromeDriver\\chromedriver_win32//chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			ChromeDriver driver = new ChromeDriver(options);
			driver.get("https://rahulshettyacademy.com/AutomationPractice/");
//			ChromeOptions chromeOptions = new ChromeOptions();
//			WebDriverManager.chromedriver().setup();
//			ChromeDriver driver = new ChromeDriver(chromeOptions);
//			driver.get("https://rahulshettyacademy.com/AutomationPractice/");



	}

}
