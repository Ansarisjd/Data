package Selenium_Training.Selenium_Training;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class OpeningNewTab {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Divyesh Pawaskar\\Documents\\Sajid Ansari\\ChromeDriver\\chromedriver_win32//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();
		WebElement footerdriver = driver.findElement(By.xpath("//*[@id=\"gf-BIG\"]/table/tbody/tr/td[1]/ul"));
		List <WebElement> columndriver = footerdriver.findElements(By.tagName("a"));
		for(int i = 1;i<columndriver.size();i++)
		{
		 String clickonlink= Keys.chord(Keys.CONTROL,Keys.ENTER);
		 columndriver.get(i).sendKeys(clickonlink); 
	}
        
		Thread.sleep(5000);
		Set<String> abc = driver.getWindowHandles();
        Iterator<String> it = abc.iterator();
        
        while(it.hasNext());
        {
        	driver.switchTo().window(it.next());
        	driver.getTitle();
        	driver.close();
        	
        	
        	
        }
        
        
	  

	
}
}