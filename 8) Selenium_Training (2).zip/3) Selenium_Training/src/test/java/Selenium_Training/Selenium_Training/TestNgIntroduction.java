package Selenium_Training.Selenium_Training;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestNgIntroduction {
    ChromeDriver driver; // Declare the driver outside methods
    
    @Test
    public void Login() throws InterruptedException { // Handle InterruptedException
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        driver = new ChromeDriver(options);
        
        driver.get("https://rahulshettyacademy.com/AutomationPractice/");
        driver.manage().window().maximize();
        
        driver.findElement(By.id("name")).click();
        driver.findElement(By.id("name")).sendKeys("Sajid");
        driver.findElement(By.id("alertbtn")).click();
        Thread.sleep(2000);
        driver.switchTo().alert().accept();
        driver.quit(); // Use quit() instead of close()
    }
}


    
    
    	
        
        
        




		
	



  