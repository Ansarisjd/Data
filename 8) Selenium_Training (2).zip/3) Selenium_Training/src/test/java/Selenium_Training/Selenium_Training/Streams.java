package Selenium_Training.Selenium_Training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Stream;

import org.testng.annotations.Test;

import com.beust.jcommander.Strings;

public class Streams {
	
    
	public static void main(String[] args) {
	// TODO Auto-generated method stub
    ArrayList<String> names =new  ArrayList<String>();
    names.add("Hashim");
    names.add("Harshad");
    names.add("sagar");
    names.add("Meraj");
    
    Long c = names.stream().filter(s-> s.startsWith("H")).count();
    System.out.println(c);
    
    System.out.println(Stream.of("Jadhav","Karan","Jamal","Usman").filter(s-> s.startsWith("U")).count());
    
	
    	
    
    
	}

}
