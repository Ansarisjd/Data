package Selenium_Training.Selenium_Training;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;


public class AddingItemsIntoCart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Divyesh Pawaskar\\Documents\\Sajid Ansari\\ChromeDriver\\chromedriver_win32//chromedriver.exe");
//		WebDriver driver = new EdgeDriver();
//		driver.get("https://www.geeksforgeeks.org/how-to-open-microsoft-edge-browser-using-selenium-in-java/");
//		Thread.sleep(5000);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");	
		ChromeDriver driver = new ChromeDriver(options);

// 1) Alert Handle Example		
//		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
//        driver.manage().window().maximize();
//        driver.findElement(By.id("name")).click();
//        driver.findElement(By.id("name")).sendKeys("Sajid");
//        driver.findElement(By.id("alertbtn")).click();
//        Thread.sleep(2000);
//        driver.switchTo().alert().accept();
//        driver.close();

// 2) Assertion Example
		
//		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
//        driver.manage().window().maximize();
//        System.out.println(driver.findElement(By.xpath("/html/body/h1")).getText());
//        Assert.assertEquals("Practice Page",driver.findElement(By.xpath("/html/body/h1")).getText());
//        driver.close();
		
// 3) Adding Product to Cart
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
        driver.manage().window().maximize();
        List<WebElement> DropDowns = driver.findElements(By.cssSelector("h4.product-name"));
        for(int i = 0;i<DropDowns.size();i++)
        {
        String name = DropDowns.get(i).getText();
        if(name.contains("Cauliflower"))
        {
        	driver.findElements(By.xpath("//button[text()='ADD TO CART']")).get(i).click();
        	break;
        
       }
        	
  //      }
        
 //  4) Adding Multiple Items into cart
		
//		String[] ItemsNeeded = {"Cucumber","Brocolli","Beetroot"};		
//		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
//        driver.manage().window().maximize();
//        List<WebElement> DropDowns = driver.findElements(By.cssSelector("h4.product-name"));
//        
//        for(int i = 0;i<DropDowns.size();i++)
//        { 
//         String name = DropDowns.get(i).getText();
//         
//        List<String> ItemsNeededList = Arrays.asList(ItemsNeeded);
//        if(ItemsNeededList.contains(name))
//        {
//        	driver.findElements(By.xpath("//button[text()='ADD TO CART']")).get(i).click();
//        }
//       
//        
//        }
//        
//       
//        
        
        }
	}
}
	

        
	
