package Selenium_Training.Selenium_Training;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;



public class ScreenShotCode {

	public static void main(String[] args) throws IOException {
	// TODO Auto-generated method stub
	
	    	System.setProperty("webdriver.chrome.driver",
						"C:\\\\Users\\\\Divyesh Pawaskar\\\\Documents\\\\Sajid Ansari\\\\ChromeDriver\\\\chromedriver-win64 in use\\\\chromedriver-win64 V_120//chromedriver.exe");
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--remote-allow-origins=*");
				ChromeDriver driver = new ChromeDriver(options);
		       // Handing Keyboard with selenium using Actions Class
				driver.get("https://www.amazon.com/");
		    	
			       	 TakesScreenshot ts = (TakesScreenshot)driver;
			       	 File source = ts.getScreenshotAs(OutputType.FILE);
			       	 File file = new File(System.getProperty("Desktop\\Tc1.png"));
			       	 FileUtils.copyFile(source, file);
			       	 return;
			        
			        }
		    }
	