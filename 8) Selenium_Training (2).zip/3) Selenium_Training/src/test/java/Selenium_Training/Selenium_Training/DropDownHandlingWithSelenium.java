package Selenium_Training.Selenium_Training;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;


public class DropDownHandlingWithSelenium {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Divyesh Pawaskar\\Documents\\Sajid Ansari\\ChromeDriver\\chromedriver_win32//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);
		
//		1) code for handling static dropdown (note:- if the element is starting from select when we inspect the element then only it is consider as static
//		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
//		driver.manage().window().maximize();
//		WebElement StaticDropdown = driver.findElement(By.id("dropdown-class-example"));		
//		Select Dropdown = new Select(StaticDropdown);
//		Dropdown.selectByIndex(3);// By Index
//		Thread.sleep(3000);
//		System.out.println(Dropdown.getFirstSelectedOption().getText());
//    	Dropdown.selectByVisibleText("Option2"); // By Visible Text 
//    	System.out.println(Dropdown.getFirstSelectedOption().getText());
//		driver.close();
		
//      2) code for handling Dynamic Dropdown

        driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
        driver.manage().window().maximize();
        driver.findElement(By.xpath("//*[@id=\"ctl00_mainContent_ddl_originStation1_CTXT\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"ctl00_mainContent_ddl_originStation1_CTNR\"]//*[@id=\"dropdownGroup1\"]/div/ul[1]/li[8]/a")).click();
        driver.findElement(By.id("ctl00_mainContent_ddl_destinationStation1_CTXT")).click();
        driver.findElement(By.xpath("/html/body/form/div[4]/div[2]/div/div[5]/div[2]/div[2]/div[2]/div[3]/div/div[3]/div/div[2]/div[2]/div/table/tbody/tr[2]/td[2]/div[3]/div[1]/div/ul[1]/li[8]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div[1]/table/tbody/tr[4]/td[3]/a")).click();
        driver.findElement(By.xpath("//*[@id=\"divpaxinfo\"]")).click();
        //driver.findElement(By.xpath("//*[@id=\"hrefIncAdt\"]")).click();
        // for adding 5 adults we need to click 4 time on plus sign for this purpose instead of manual click we have run while loops.
        int i=1;
        while(i<5)
        {
        	driver.findElement(By.xpath("//*[@id=\"hrefIncAdt\"]")).click();
        	i++;
        }
        
        // for selecting india we are sending ind then from three matches we need to select india we need to run for loops.
        driver.findElement(By.xpath("//*[@id=\"autosuggest\"]")).sendKeys("ind");
        Thread.sleep(3000);
        java.util.List<WebElement> Suggestions = driver.findElements(By.cssSelector("li.ui-menu-item"));
        
        for (WebElement Suggestion : Suggestions)
        {
        	if(Suggestion.getText().equalsIgnoreCase("India"))
        	{
        		Suggestion.click();
        		break;
        	}
        }
        Thread.sleep(3000);
        driver.close();
        
        
        
     
   
        
        
     
    
 
        
        
       
        
        
        
        
        
		

	}

}
