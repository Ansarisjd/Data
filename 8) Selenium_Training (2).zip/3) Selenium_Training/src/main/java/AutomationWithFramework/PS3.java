package AutomationWithFramework;

import bsh.This;

public class PS3 {
    int a;
    PS3(int a) {
		this.a = a;
	}
    
    
    public int multiply(){
		a = a * 5 ;
		return a;

	}


}
