package AutomationWithFramework;


public class PS2 extends PS3{
    
	int a;
	
	 PS2(int a) {
		super(a);
		 this.a = a;
	}

	public int increament(){
		a = a + 1 ;
		return a;

	}
  
	public int Decreament(){
		a = a - 1 ;
		return a;

	}
}
